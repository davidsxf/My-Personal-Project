# -*- coding: utf-8 -*-
"""
DecisionTreeRegressor.py
"""
import numpy as np
from sklearn.tree import  DecisionTreeRegressor
import matplotlib.pyplot as plt

# 随机创建一个数据集
rng=np.random.RandomState(1)
X=np.sort(5*rng.rand(80,1),axis=0)
Y=np.sin(X).ravel()
Y[: : 5]+=3*(0.5-rng.rand(16))   # 给数据集加上一个噪音

#训练三种不同最大深度的回归树模型
clf_1=DecisionTreeRegressor(max_depth=2)   #过于简单
clf_2=DecisionTreeRegressor(max_depth=4)   
clf_3=DecisionTreeRegressor(max_depth=6)   #过度拟合

clf_1.fit(X,Y)
clf_2.fit(X,Y)
clf_3.fit(X,Y)


# 利用回归模型进行预测
X_test=np.arange(0.0,5.0,0.01)[: , np.newaxis]
Y_1=clf_1.predict(X_test)
Y_2=clf_2.predict(X_test)
Y_3=clf_3.predict(X_test)


# 绘制散点图和回归曲线
plt.figure()
plt.scatter(X,Y,c="k",label="data")
plt.plot(X_test,Y_1,c="g",label="max_depth=2",linewidth=2)
plt.plot(X_test,Y_2,c="r",label="max_depth=4",linewidth=2)
plt.plot(X_test,Y_3,c="b",label="max_depth=6",linewidth=2)

plt.xlabel("data")
plt.ylabel("target")
plt.title("Decision Tree Regression")
plt.legend()
plt.show()