# -*- coding: utf-8 -*-
import numpy as np
import matplotlib.pylab as plt
from sklearn.datasets import load_iris
from sklearn.tree import DecisionTreeClassifier

iris=load_iris()

# 将四个特征两两组队，每一次迭代是6组特征组合中的一种
for pairidx,pair in enumerate([[0,1],[0,2],[0,3],[1,2],[1,3],[2,3]]):
    X=iris.data[:,pair]
    Y=iris.target
    
    
# 随机打乱样本顺序
idx=np.arange(X.shape[0])
np.random.seed(13)
np.random.shuffle(idx)
X=X[idx]
Y=Y[idx]


# 归一化样本数据
mean=X.mean(axis=0)
std=X.std(axis=0)
X=(X-mean)/std


# 训练模型
clf=DecisionTreeClassifier().fit(X,Y)

# 画出一个2行3列的图形的结合，同时画出网格来填充决策边界
plt.subplot(2,3,pairidx+1)
x_min,x_max=X[: , 0].min()-1,X[: , 0].max()+1
y_min,y_max=X[: , 1].min()-1,X[: , 1].max()+1
xx,yy=np.meshgrid(np.arange(x_min,x_max,0.02),
                  np.arange(y_min,y_max,0.02))
Z=clf.predict(np.c_[xx.ravel(),yy.ravel()])
Z=Z.reshape(xx.shape)
cs=plt.contourf(xx,yy,Z,cmap=plt.cm.Paired)

# 以特征名作为X轴，Y轴名称
plt.xlabel(iris.feature_names[pair[0]])
plt.ylabel(iris.feature_names[pair[1]])
plt.axis("tight")

# 按照原始数据集的分类填充点
for i,color in [(0,'b'),(1,'r'),(2,'y')]:
    # 筛选出第i类的样本，并按类别给数据点填充颜色
    idx=np.where(Y==i)
    plt.scatter(X[idx,0],X[idx,1],c=color,label=iris.target_names[i],cmap=plt.cm.Paired)
    plt.axis("tight")
    

# 绘制表名和图例
plt.suptitle("Decision surface of a decision tree using paired fearures")
plt.legend()
plt.show()