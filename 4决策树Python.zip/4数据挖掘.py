# -*- coding: utf-8 -*-


################################### 1 内置数据集            以数据集 digits为例
from sklearn import datasets
digits=datasets.load_digits()
digits
# 查看数据集的关键字、样本数量以及特征数量
digits.keys()
n_samples,n_features=digits.data.shape
print(n_samples,n_features)

# 查看每一个特征的具体值
print(digits.data)
print(digits.images)
print(digits.target)

# 查看数据集标签向量
digits.target

# 访问digits数据集中的样本
digits.images[0]

################################# 2 导入数据
# 大多数数据集都是M个N维向量，分为训练集和测试集，需要numpy协助

import numpy as np
f=open('filename.txt')
f.readline()
data=np.loadtxt(f)
X=data[:,:2]     #读取前两列
Y=data[:,-1]     #读取最后一列



################################# 3 模型接口
# 在Scikit-Learn中，创建一个线性回归机器学习的模型非常简单
from sklearn.linear_model import LinearRegression
model=LinearRegression()
print model   #查看模型回归参数


model.fit()   
'''
训练模型，对于监督模型需要两个参数样本集X和标签y,fix(X,y);
#对于非监督模型只需要接收一个样本集参数，fix(X)
'''


model.predict(X_new)
'''
给定训练好的模型来判别新的样本
'''



model.predict_proba(X_new)
model.predict()
'''
对于分类问题，模型返回某种分类标签的概率
model.predict()   #返回具有最大概率的类标签
'''


model.score() 
'''
对于分类或者回归问题，几乎所有的预测器都会提供一个计算得分的方法，计算出的得分处于[0,1]之间
得分越高，模型匹配度越高
'''


model.transform()
'''
从数据中学到新的“基空间”
'''


model.fit_transform()
'''
从数据中学到新的基，并将数据按照这组基进行转换
'''


############################### 4 模型保存
