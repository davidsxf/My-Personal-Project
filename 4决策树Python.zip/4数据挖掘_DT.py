# -*- coding: utf-8 -*-
"""
Created on Fri Oct 21 12:37:08 2016

@author: zydeve
"""

# 决策树 decision tree
import numpy as np
from sklearn import tree
from sklearn import metrics
from sklearn.datasets import load_iris
iris=load_iris()                      #加载数据集
X=iris.data
Y=iris.target
idx=np.arange(X.shape[0])
np.random.seed(13)
np.random.shuffle(idx)               #打乱数据集
X=X[idx]
Y=Y[idx]

X_train=X[X.shape[0]*0.75]           #抽取75%的作为训练集，25%为测试集
X_train=X[:X.shape[0]*0.75]
Y_train=Y[:X.shape[0]*0.75]

X_test=X[X.shape[0]*0.75]
Y_test=Y[X.shape[0]*0.75]

clf=tree.DecisionTreeClassifier()
#scikit-learn提供的 DecisionTreeClassifier既可以做二元分类，也可以做多元分类

clf=clf.fit(X_train,Y_train)        #训练模型

# 训练好决策树模型后就可以使用模型来预测新的样本，主要查看模型的
# 准确率precision      召回率recall        F1值F1-score
'''
准确率：表示算法检索出来的有多少是正确的额；
召回率：表示所有准确的条目中有多少被检索出来；   准确率和召回率越高越好，矛盾体
F1值：是准确率和召回率的综合考量，其值越高，表示算法性能越好，。

'''


# 3 测试模型
pre=clf.predict(X_test)
print(metrics.classification_report(test_target,pre,target_names=iris.target_names))


# 4 生成pdf格式的决策树图 
from sklearn.externals.six import StringIO
import pydot
dot_data=StringIO()
tree.export_graphviz(clf,out_file=dot_data)
graph=pydot.graph_from_dot_data(dot_data.getvalue())
graph.write_pdf("iris.pdf")



#５　将４个特征两两组队，画出散点图以及决策边界
# 创建DecisionTreeClassifier.py文件，